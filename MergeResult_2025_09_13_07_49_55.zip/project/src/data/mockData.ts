import { User, Offer, PaymentHistory } from '../types/subscription';

export const mockUser: User = {
  id: '1',
  name: 'Sarah Johnson',
  email: 'sarah.johnson@example.com',
  avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2',
  subscription: {
    id: 'sub-1',
    planId: 'pro',
    status: 'active',
    startDate: '2024-01-15',
    endDate: '2025-01-15',
    autoRenew: true,
    nextBillingDate: '2024-02-15',
    pricePerMonth: 29
  },
  usageStats: {
    users: 12,
    storageUsed: '45GB',
    apiCalls: 15420
  }
};

export const mockOffers: Offer[] = [
  {
    id: 'offer-1',
    title: 'Limited Time: 50% Off Pro Plan',
    description: 'Upgrade to Pro and get 50% off your first 3 months',
    discount: 50,
    validUntil: '2024-12-31',
    planIds: ['pro'],
    code: 'PRO50'
  },
  {
    id: 'offer-2',
    title: 'Enterprise Special',
    description: 'Get 25% off Enterprise plan for the first year',
    discount: 25,
    validUntil: '2024-11-30',
    planIds: ['enterprise'],
    code: 'ENT25'
  },
  {
    id: 'offer-3',
    title: 'Student Discount',
    description: '40% off any plan with valid student ID',
    discount: 40,
    validUntil: '2024-12-31',
    planIds: ['basic', 'pro'],
    code: 'STUDENT40'
  }
];

export const mockPaymentHistory: PaymentHistory[] = [
  {
    id: 'payment-1',
    date: '2024-01-15',
    amount: 29,
    status: 'completed',
    planName: 'Pro Plan',
    invoiceUrl: '#'
  },
  {
    id: 'payment-2',
    date: '2023-12-15',
    amount: 29,
    status: 'completed',
    planName: 'Pro Plan',
    invoiceUrl: '#'
  },
  {
    id: 'payment-3',
    date: '2023-11-15',
    amount: 29,
    status: 'completed',
    planName: 'Pro Plan',
    invoiceUrl: '#'
  },
  {
    id: 'payment-4',
    date: '2023-10-15',
    amount: 9,
    status: 'completed',
    planName: 'Basic Plan',
    invoiceUrl: '#'
  }
];