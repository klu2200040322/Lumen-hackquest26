import { Plan } from '../types/subscription';

export const plans: Plan[] = [
  {
    id: 'basic',
    name: 'Basic',
    price: 9,
    billingPeriod: 'monthly',
    color: 'from-gray-500 to-gray-600',
    maxUsers: 5,
    storage: '10GB',
    support: 'Email',
    features: [
      'Up to 5 team members',
      '10GB cloud storage',
      'Basic analytics',
      'Email support',
      'Mobile app access',
      'Standard templates'
    ]
  },
  {
    id: 'pro',
    name: 'Pro',
    price: 29,
    billingPeriod: 'monthly',
    popular: true,
    color: 'from-blue-500 to-blue-600',
    maxUsers: 25,
    storage: '100GB',
    support: 'Priority',
    features: [
      'Up to 25 team members',
      '100GB cloud storage',
      'Advanced analytics',
      'Priority support',
      'Custom integrations',
      'Premium templates',
      'API access',
      'Custom branding'
    ]
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    price: 99,
    billingPeriod: 'monthly',
    color: 'from-purple-500 to-purple-600',
    maxUsers: 999,
    storage: 'Unlimited',
    support: '24/7 Phone',
    features: [
      'Unlimited team members',
      'Unlimited cloud storage',
      'Enterprise analytics',
      '24/7 phone support',
      'Custom development',
      'White-label solution',
      'Advanced security',
      'Dedicated account manager',
      'SLA guarantee'
    ]
  }
];

export const yearlyPlans: Plan[] = plans.map(plan => ({
  ...plan,
  id: `${plan.id}-yearly`,
  price: Math.round(plan.price * 12 * 0.8), // 20% discount for yearly
  billingPeriod: 'yearly' as const
}));