import React from 'react';
import { Calendar, CreditCard, Users, HardDrive, TrendingUp, AlertCircle } from 'lucide-react';
import { User, Subscription } from '../types/subscription';
import { plans } from '../data/plans';

interface SubscriptionStatusProps {
  user: User;
  onCancelSubscription: () => void;
  onRenewSubscription: () => void;
  onToggleAutoRenew: () => void;
  isLoading: boolean;
}

export const SubscriptionStatus: React.FC<SubscriptionStatusProps> = ({
  user,
  onCancelSubscription,
  onRenewSubscription,
  onToggleAutoRenew,
  isLoading
}) => {
  if (!user.subscription) {
    return (
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
        <div className="text-center py-8">
          <AlertCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">No Active Subscription</h3>
          <p className="text-gray-600">Choose a plan to get started with our services.</p>
        </div>
      </div>
    );
  }

  const subscription = user.subscription;
  const currentPlan = plans.find(p => p.id === subscription.planId);
  const statusColor = {
    active: 'bg-emerald-100 text-emerald-700',
    canceled: 'bg-red-100 text-red-700',
    expired: 'bg-gray-100 text-gray-700',
    pending: 'bg-yellow-100 text-yellow-700'
  }[subscription.status];

  const usagePercentage = {
    users: (user.usageStats.users / (currentPlan?.maxUsers || 1)) * 100,
    storage: parseInt(user.usageStats.storageUsed) / parseInt(currentPlan?.storage || '100') * 100,
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-200">
      {/* Header */}
      <div className="p-6 border-b border-gray-100">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-gray-900">Current Subscription</h2>
          <span className={`px-3 py-1 rounded-full text-sm font-medium ${statusColor}`}>
            {subscription.status.charAt(0).toUpperCase() + subscription.status.slice(1)}
          </span>
        </div>
        
        {currentPlan && (
          <div className="flex items-center gap-4">
            <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${currentPlan.color} flex items-center justify-center`}>
              <span className="text-white font-bold text-lg">{currentPlan.name[0]}</span>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900">{currentPlan.name} Plan</h3>
              <p className="text-gray-600">${subscription.pricePerMonth}/month</p>
            </div>
          </div>
        )}
      </div>

      {/* Subscription Details */}
      <div className="p-6 space-y-6">
        {/* Billing Info */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <Calendar className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Next Billing</p>
              <p className="font-semibold text-gray-900">
                {new Date(subscription.nextBillingDate).toLocaleDateString()}
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center">
              <CreditCard className="h-5 w-5 text-emerald-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Auto Renew</p>
              <p className="font-semibold text-gray-900">
                {subscription.autoRenew ? 'Enabled' : 'Disabled'}
              </p>
            </div>
          </div>
        </div>

        {/* Usage Stats */}
        <div className="space-y-4">
          <h4 className="font-semibold text-gray-900">Usage Statistics</h4>
          
          <div className="space-y-4">
            {/* Users */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                <Users className="h-5 w-5 text-purple-600" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium text-gray-700">Team Members</span>
                  <span className="text-sm text-gray-600">
                    {user.usageStats.users} / {currentPlan?.maxUsers === 999 ? '∞' : currentPlan?.maxUsers}
                  </span>
                </div>
                {currentPlan?.maxUsers !== 999 && (
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-purple-500 h-2 rounded-full transition-all duration-500"
                      style={{ width: `${Math.min(usagePercentage.users, 100)}%` }}
                    />
                  </div>
                )}
              </div>
            </div>

            {/* Storage */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                <HardDrive className="h-5 w-5 text-orange-600" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium text-gray-700">Storage Used</span>
                  <span className="text-sm text-gray-600">
                    {user.usageStats.storageUsed} / {currentPlan?.storage}
                  </span>
                </div>
                {currentPlan?.storage !== 'Unlimited' && (
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-orange-500 h-2 rounded-full transition-all duration-500"
                      style={{ width: `${Math.min(usagePercentage.storage, 100)}%` }}
                    />
                  </div>
                )}
              </div>
            </div>

            {/* API Calls */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-teal-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="h-5 w-5 text-teal-600" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-700">API Calls This Month</span>
                  <span className="text-sm text-gray-600">
                    {user.usageStats.apiCalls.toLocaleString()}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-gray-100">
          <button
            onClick={onToggleAutoRenew}
            disabled={isLoading}
            className={`flex-1 py-2 px-4 rounded-lg font-medium transition-colors ${
              subscription.autoRenew
                ? 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                : 'bg-emerald-100 text-emerald-700 hover:bg-emerald-200'
            } ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            {subscription.autoRenew ? 'Disable Auto-Renew' : 'Enable Auto-Renew'}
          </button>
          
          {subscription.status === 'canceled' ? (
            <button
              onClick={onRenewSubscription}
              disabled={isLoading}
              className={`flex-1 py-2 px-4 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors ${
                isLoading ? 'opacity-50 cursor-not-allowed' : ''
              }`}
            >
              Renew Subscription
            </button>
          ) : (
            <button
              onClick={onCancelSubscription}
              disabled={isLoading}
              className={`flex-1 py-2 px-4 bg-red-100 text-red-700 rounded-lg font-medium hover:bg-red-200 transition-colors ${
                isLoading ? 'opacity-50 cursor-not-allowed' : ''
              }`}
            >
              Cancel Subscription
            </button>
          )}
        </div>
      </div>
    </div>
  );
};