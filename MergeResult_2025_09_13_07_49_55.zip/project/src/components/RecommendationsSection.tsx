import React from 'react';
import { Lightbulb, ArrowRight, TrendingUp } from 'lucide-react';
import { User } from '../types/subscription';
import { plans } from '../data/plans';

interface RecommendationsSectionProps {
  user: User;
  onSelectPlan: (plan: any) => void;
}

export const RecommendationsSection: React.FC<RecommendationsSectionProps> = ({
  user,
  onSelectPlan
}) => {
  const getRecommendations = () => {
    const currentPlanId = user.subscription?.planId;
    const usageStats = user.usageStats;
    
    // Simple recommendation logic based on usage
    if (usageStats.users > 20 && currentPlanId !== 'enterprise') {
      return {
        plan: plans.find(p => p.id === 'enterprise'),
        reason: 'Your team is growing! Enterprise plan offers unlimited users and advanced features.'
      };
    }
    
    if (usageStats.users > 15 && currentPlanId === 'basic') {
      return {
        plan: plans.find(p => p.id === 'pro'),
        reason: 'You\'re approaching your user limit. Pro plan gives you more flexibility.'
      };
    }
    
    if (parseInt(usageStats.storageUsed) > 80 && currentPlanId === 'basic') {
      return {
        plan: plans.find(p => p.id === 'pro'),
        reason: 'You\'re running low on storage. Pro plan offers 10x more storage space.'
      };
    }

    return null;
  };

  const recommendation = getRecommendations();

  if (!recommendation) {
    return (
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center">
            <Lightbulb className="h-5 w-5 text-emerald-600" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900">Recommendations</h3>
        </div>
        <div className="text-center py-8">
          <TrendingUp className="h-12 w-12 text-emerald-500 mx-auto mb-4" />
          <p className="text-gray-600">Your current plan perfectly fits your usage. Keep up the great work!</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-br from-emerald-50 to-teal-50 rounded-2xl border border-emerald-200 p-6">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 bg-emerald-500 rounded-lg flex items-center justify-center">
          <Lightbulb className="h-5 w-5 text-white" />
        </div>
        <h3 className="text-lg font-semibold text-gray-900">Recommended for You</h3>
      </div>

      <div className="bg-white rounded-xl p-4 mb-4">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h4 className="font-semibold text-gray-900">{recommendation.plan?.name} Plan</h4>
            <p className="text-2xl font-bold text-emerald-600">${recommendation.plan?.price}/month</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-500">Upgrade Benefits</p>
            <p className="font-medium text-gray-900">
              {recommendation.plan?.maxUsers === 999 ? 'Unlimited' : recommendation.plan?.maxUsers} users
            </p>
          </div>
        </div>
        
        <p className="text-gray-700 text-sm mb-4">{recommendation.reason}</p>
        
        <button
          onClick={() => onSelectPlan(recommendation.plan)}
          className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 text-white py-2 px-4 rounded-lg font-medium hover:from-emerald-600 hover:to-teal-600 transition-colors flex items-center justify-center gap-2"
        >
          Upgrade Now
          <ArrowRight className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
};