import React, { useState } from 'react';
import { PlanCard } from './PlanCard';
import { BillingToggle } from './BillingToggle';
import { Plan } from '../types/subscription';
import { plans, yearlyPlans } from '../data/plans';

interface PlansSectionProps {
  currentPlanId?: string;
  onSelectPlan: (plan: Plan) => void;
  isLoading: boolean;
}

export const PlansSection: React.FC<PlansSectionProps> = ({
  currentPlanId,
  onSelectPlan,
  isLoading
}) => {
  const [isYearly, setIsYearly] = useState(false);
  const displayPlans = isYearly ? yearlyPlans : plans;

  // Add recommendations based on current plan
  const plansWithRecommendations = displayPlans.map(plan => {
    if (currentPlanId === 'basic' && plan.id === 'pro') {
      return { ...plan, recommended: true };
    }
    if (currentPlanId === 'pro' && plan.id === 'enterprise') {
      return { ...plan, recommended: true };
    }
    return plan;
  });

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">
          Choose the Perfect Plan
        </h2>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Scale your business with our flexible pricing plans. Upgrade or downgrade anytime.
        </p>
      </div>

      {/* Billing Toggle */}
      <BillingToggle isYearly={isYearly} onToggle={setIsYearly} />

      {/* Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
        {plansWithRecommendations.map((plan) => (
          <PlanCard
            key={plan.id}
            plan={plan}
            currentPlanId={currentPlanId}
            onSelectPlan={onSelectPlan}
            isLoading={isLoading}
          />
        ))}
      </div>

      {/* Enterprise Contact */}
      <div className="bg-gray-50 rounded-2xl p-8 text-center">
        <h3 className="text-xl font-semibold text-gray-900 mb-4">
          Need a Custom Solution?
        </h3>
        <p className="text-gray-600 mb-6">
          Contact our sales team for custom enterprise solutions tailored to your specific needs.
        </p>
        <button className="bg-gray-900 text-white px-6 py-3 rounded-lg font-medium hover:bg-gray-800 transition-colors">
          Contact Sales
        </button>
      </div>
    </div>
  );
};