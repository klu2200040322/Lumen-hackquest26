import React, { useState } from 'react';
import { Gift, Clock, Copy, Check } from 'lucide-react';
import { Offer } from '../types/subscription';
import { mockOffers } from '../data/mockData';

export const OffersSection: React.FC = () => {
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
          <Gift className="h-5 w-5 text-orange-600" />
        </div>
        <h3 className="text-lg font-semibold text-gray-900">Special Offers</h3>
      </div>

      <div className="space-y-4">
        {mockOffers.map((offer) => (
          <div
            key={offer.id}
            className="bg-gradient-to-r from-orange-50 to-pink-50 rounded-xl p-4 border border-orange-200"
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex-1">
                <h4 className="font-semibold text-gray-900 mb-1">{offer.title}</h4>
                <p className="text-sm text-gray-600 mb-2">{offer.description}</p>
                
                <div className="flex items-center gap-4 text-xs text-gray-500">
                  <div className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    Valid until {formatDate(offer.validUntil)}
                  </div>
                  <div className="font-medium text-orange-600">
                    {offer.discount}% OFF
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 bg-white px-3 py-2 rounded-lg border border-gray-200">
                <span className="text-sm font-mono text-gray-700">{offer.code}</span>
                <button
                  onClick={() => copyCode(offer.code)}
                  className="p-1 hover:bg-gray-100 rounded transition-colors"
                >
                  {copiedCode === offer.code ? (
                    <Check className="h-3 w-3 text-emerald-500" />
                  ) : (
                    <Copy className="h-3 w-3 text-gray-400" />
                  )}
                </button>
              </div>
              
              <button className="bg-gradient-to-r from-orange-500 to-pink-500 text-white px-4 py-2 rounded-lg text-sm font-medium hover:from-orange-600 hover:to-pink-600 transition-colors">
                Apply Offer
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};