import React from 'react';
import { Check, Star, Zap } from 'lucide-react';
import { Plan } from '../types/subscription';

interface PlanCardProps {
  plan: Plan;
  currentPlanId?: string;
  onSelectPlan: (plan: Plan) => void;
  isLoading?: boolean;
}

export const PlanCard: React.FC<PlanCardProps> = ({ 
  plan, 
  currentPlanId, 
  onSelectPlan, 
  isLoading 
}) => {
  const isCurrentPlan = currentPlanId === plan.id;
  const isPopular = plan.popular;
  const isRecommended = plan.recommended;

  return (
    <div className={`relative bg-white rounded-2xl shadow-sm border-2 transition-all duration-300 hover:shadow-xl hover:-translate-y-1 ${
      isCurrentPlan ? 'border-blue-500 ring-2 ring-blue-100' : 
      isPopular ? 'border-purple-300' : 'border-gray-200 hover:border-gray-300'
    }`}>
      {/* Popular Badge */}
      {isPopular && (
        <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
          <div className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 py-1 rounded-full text-sm font-medium flex items-center gap-1">
            <Star className="h-3 w-3" />
            Most Popular
          </div>
        </div>
      )}

      {/* Recommended Badge */}
      {isRecommended && (
        <div className="absolute -top-4 right-4">
          <div className="bg-gradient-to-r from-emerald-500 to-teal-500 text-white px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1">
            <Zap className="h-3 w-3" />
            Recommended
          </div>
        </div>
      )}

      <div className="p-6 sm:p-8">
        {/* Plan Header */}
        <div className="text-center mb-6">
          <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
          <div className="flex items-baseline justify-center gap-1">
            <span className="text-4xl font-bold text-gray-900">${plan.price}</span>
            <span className="text-gray-500">/{plan.billingPeriod === 'yearly' ? 'year' : 'month'}</span>
          </div>
          {plan.billingPeriod === 'yearly' && (
            <p className="text-sm text-emerald-600 font-medium mt-1">
              Save 20% with yearly billing
            </p>
          )}
        </div>

        {/* Plan Stats */}
        <div className="grid grid-cols-3 gap-4 mb-6 p-4 bg-gray-50 rounded-xl">
          <div className="text-center">
            <p className="text-xs text-gray-500 mb-1">Users</p>
            <p className="font-semibold text-gray-900">{plan.maxUsers === 999 ? 'Unlimited' : plan.maxUsers}</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-gray-500 mb-1">Storage</p>
            <p className="font-semibold text-gray-900">{plan.storage}</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-gray-500 mb-1">Support</p>
            <p className="font-semibold text-gray-900">{plan.support}</p>
          </div>
        </div>

        {/* Features */}
        <ul className="space-y-3 mb-8">
          {plan.features.map((feature, index) => (
            <li key={index} className="flex items-start gap-3">
              <div className="w-5 h-5 rounded-full bg-emerald-100 flex items-center justify-center mt-0.5 flex-shrink-0">
                <Check className="h-3 w-3 text-emerald-600" />
              </div>
              <span className="text-gray-700 text-sm leading-relaxed">{feature}</span>
            </li>
          ))}
        </ul>

        {/* Action Button */}
        <button
          onClick={() => onSelectPlan(plan)}
          disabled={isCurrentPlan || isLoading}
          className={`w-full py-3 px-4 rounded-xl font-medium transition-all duration-200 ${
            isCurrentPlan
              ? 'bg-gray-100 text-gray-500 cursor-not-allowed'
              : isPopular
              ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600 shadow-lg hover:shadow-xl'
              : 'bg-gradient-to-r from-blue-500 to-blue-600 text-white hover:from-blue-600 hover:to-blue-700 shadow-lg hover:shadow-xl'
          } ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          {isLoading ? (
            <div className="flex items-center justify-center gap-2">
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              Processing...
            </div>
          ) : isCurrentPlan ? (
            'Current Plan'
          ) : (
            `Select ${plan.name}`
          )}
        </button>
      </div>
    </div>
  );
};