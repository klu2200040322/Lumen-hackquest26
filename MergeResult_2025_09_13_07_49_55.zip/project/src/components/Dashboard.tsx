import React from 'react';
import { SubscriptionStatus } from './SubscriptionStatus';
import { RecommendationsSection } from './RecommendationsSection';
import { OffersSection } from './OffersSection';
import { PaymentHistory } from './PaymentHistory';
import { User } from '../types/subscription';

interface DashboardProps {
  user: User;
  onSelectPlan: (plan: any) => void;
  onCancelSubscription: () => void;
  onRenewSubscription: () => void;
  onToggleAutoRenew: () => void;
  isLoading: boolean;
}

export const Dashboard: React.FC<DashboardProps> = ({
  user,
  onSelectPlan,
  onCancelSubscription,
  onRenewSubscription,
  onToggleAutoRenew,
  isLoading
}) => {
  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-6 text-white">
        <h2 className="text-2xl font-bold mb-2">Welcome back, {user.name}!</h2>
        <p className="text-blue-100">
          Manage your subscription, track usage, and discover new features.
        </p>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column - Subscription Status */}
        <div className="lg:col-span-2">
          <SubscriptionStatus
            user={user}
            onCancelSubscription={onCancelSubscription}
            onRenewSubscription={onRenewSubscription}
            onToggleAutoRenew={onToggleAutoRenew}
            isLoading={isLoading}
          />
        </div>

        {/* Right Column - Recommendations */}
        <div>
          <RecommendationsSection
            user={user}
            onSelectPlan={onSelectPlan}
          />
        </div>
      </div>

      {/* Bottom Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <OffersSection />
        <PaymentHistory />
      </div>
    </div>
  );
};