export interface Plan {
  id: string;
  name: string;
  price: number;
  billingPeriod: 'monthly' | 'yearly';
  features: string[];
  popular?: boolean;
  recommended?: boolean;
  color: string;
  maxUsers: number;
  storage: string;
  support: string;
}

export interface Subscription {
  id: string;
  planId: string;
  status: 'active' | 'canceled' | 'expired' | 'pending';
  startDate: string;
  endDate: string;
  autoRenew: boolean;
  nextBillingDate: string;
  pricePerMonth: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  subscription?: Subscription;
  usageStats: {
    users: number;
    storageUsed: string;
    apiCalls: number;
  };
}

export interface Offer {
  id: string;
  title: string;
  description: string;
  discount: number;
  validUntil: string;
  planIds: string[];
  code: string;
}

export interface PaymentHistory {
  id: string;
  date: string;
  amount: number;
  status: 'completed' | 'pending' | 'failed';
  planName: string;
  invoiceUrl?: string;
}