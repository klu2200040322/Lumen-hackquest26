import { useState, useCallback } from 'react';
import { Plan, Subscription } from '../types/subscription';
import { mockUser } from '../data/mockData';

export const useSubscription = () => {
  const [user, setUser] = useState(mockUser);
  const [isLoading, setIsLoading] = useState(false);

  const subscribeToPlan = useCallback(async (plan: Plan) => {
    setIsLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const newSubscription: Subscription = {
      id: `sub-${Date.now()}`,
      planId: plan.id,
      status: 'active',
      startDate: new Date().toISOString().split('T')[0],
      endDate: new Date(Date.now() + (plan.billingPeriod === 'yearly' ? 365 : 30) * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      autoRenew: true,
      nextBillingDate: new Date(Date.now() + (plan.billingPeriod === 'yearly' ? 365 : 30) * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      pricePerMonth: plan.billingPeriod === 'yearly' ? Math.round(plan.price / 12) : plan.price
    };

    setUser(prev => ({
      ...prev,
      subscription: newSubscription
    }));
    setIsLoading(false);
  }, []);

  const cancelSubscription = useCallback(async () => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    setUser(prev => ({
      ...prev,
      subscription: prev.subscription ? {
        ...prev.subscription,
        status: 'canceled',
        autoRenew: false
      } : undefined
    }));
    setIsLoading(false);
  }, []);

  const renewSubscription = useCallback(async () => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    setUser(prev => ({
      ...prev,
      subscription: prev.subscription ? {
        ...prev.subscription,
        status: 'active',
        autoRenew: true
      } : undefined
    }));
    setIsLoading(false);
  }, []);

  const toggleAutoRenew = useCallback(async () => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 500));
    
    setUser(prev => ({
      ...prev,
      subscription: prev.subscription ? {
        ...prev.subscription,
        autoRenew: !prev.subscription.autoRenew
      } : undefined
    }));
    setIsLoading(false);
  }, []);

  return {
    user,
    isLoading,
    subscribeToPlan,
    cancelSubscription,
    renewSubscription,
    toggleAutoRenew
  };
};