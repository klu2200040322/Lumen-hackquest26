import React, { useState } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { PlansSection } from './components/PlansSection';
import { LoadingSpinner } from './components/LoadingSpinner';
import { SuccessModal } from './components/SuccessModal';
import { useSubscription } from './hooks/useSubscription';
import { Plan } from './types/subscription';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [successModal, setSuccessModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
  }>({
    isOpen: false,
    title: '',
    message: ''
  });

  const {
    user,
    isLoading,
    subscribeToPlan,
    cancelSubscription,
    renewSubscription,
    toggleAutoRenew
  } = useSubscription();

  const handleSelectPlan = async (plan: Plan) => {
    await subscribeToPlan(plan);
    setSuccessModal({
      isOpen: true,
      title: 'Subscription Updated!',
      message: `You've successfully subscribed to the ${plan.name} plan. Welcome aboard!`
    });
  };

  const handleCancelSubscription = async () => {
    await cancelSubscription();
    setSuccessModal({
      isOpen: true,
      title: 'Subscription Canceled',
      message: 'Your subscription has been canceled. You can continue using the service until the end of your billing period.'
    });
  };

  const handleRenewSubscription = async () => {
    await renewSubscription();
    setSuccessModal({
      isOpen: true,
      title: 'Subscription Renewed!',
      message: 'Your subscription has been successfully renewed. Thank you for staying with us!'
    });
  };

  const handleToggleAutoRenew = async () => {
    await toggleAutoRenew();
    const newStatus = user.subscription?.autoRenew ? 'disabled' : 'enabled';
    setSuccessModal({
      isOpen: true,
      title: 'Auto-Renew Updated',
      message: `Auto-renew has been ${newStatus} for your subscription.`
    });
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <Dashboard
            user={user}
            onSelectPlan={handleSelectPlan}
            onCancelSubscription={handleCancelSubscription}
            onRenewSubscription={handleRenewSubscription}
            onToggleAutoRenew={handleToggleAutoRenew}
            isLoading={isLoading}
          />
        );
      case 'plans':
        return (
          <PlansSection
            currentPlanId={user.subscription?.planId}
            onSelectPlan={handleSelectPlan}
            isLoading={isLoading}
          />
        );
      case 'settings':
        return (
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Account Settings</h2>
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Full Name
                </label>
                <input
                  type="text"
                  value={user.name}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  readOnly
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  value={user.email}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  readOnly
                />
              </div>
              <button className="bg-blue-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors">
                Update Profile
              </button>
            </div>
          </div>
        );
      case 'help':
        return (
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Help & Support</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="p-6 bg-blue-50 rounded-xl">
                <h3 className="font-semibold text-gray-900 mb-2">Documentation</h3>
                <p className="text-gray-600 text-sm mb-4">
                  Browse our comprehensive guides and tutorials.
                </p>
                <button className="text-blue-600 font-medium hover:text-blue-700">
                  View Docs →
                </button>
              </div>
              <div className="p-6 bg-emerald-50 rounded-xl">
                <h3 className="font-semibold text-gray-900 mb-2">Contact Support</h3>
                <p className="text-gray-600 text-sm mb-4">
                  Get help from our friendly support team.
                </p>
                <button className="text-emerald-600 font-medium hover:text-emerald-700">
                  Contact Us →
                </button>
              </div>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex">
        <Sidebar
          activeTab={activeTab}
          onTabChange={setActiveTab}
          isOpen={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
        />
        
        <div className="flex-1 lg:ml-0">
          <Header
            user={user}
            onMenuClick={() => setSidebarOpen(true)}
          />
          
          <main className="p-4 sm:p-6 lg:p-8">
            <div className="max-w-7xl mx-auto">
              {renderContent()}
            </div>
          </main>
        </div>
      </div>

      {isLoading && <LoadingSpinner />}
      
      <SuccessModal
        isOpen={successModal.isOpen}
        onClose={() => setSuccessModal({ ...successModal, isOpen: false })}
        title={successModal.title}
        message={successModal.message}
      />
    </div>
  );
}

export default App;