import React from 'react';
import { User as UserIcon, Shield, Settings, LogOut, Users, CreditCard } from 'lucide-react';
import { User } from '../hooks/useAuth';

interface DashboardProps {
  user: User;
  onSignOut: () => void;
}

export default function Dashboard({ user, onSignOut }: DashboardProps) {
  const isAdmin = user.role === 'admin';

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="flex items-center justify-center w-8 h-8 bg-blue-600 rounded-lg">
                <Shield className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-xl font-semibold text-gray-900">
                Subscription Manager
              </h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
                  isAdmin ? 'bg-purple-100' : 'bg-blue-100'
                }`}>
                  {isAdmin ? (
                    <Shield className="w-4 h-4 text-purple-600" />
                  ) : (
                    <UserIcon className="w-4 h-4 text-blue-600" />
                  )}
                </div>
                <div className="hidden sm:block">
                  <p className="text-sm font-medium text-gray-900">{user.fullName}</p>
                  <p className="text-xs text-gray-500 capitalize">{user.role}</p>
                </div>
              </div>
              
              <button
                onClick={onSignOut}
                className="inline-flex items-center px-3 py-2 border border-transparent text-sm font-medium rounded-lg text-gray-700 bg-gray-100 hover:bg-gray-200 transition-colors"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Sign Out
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl p-8 text-white mb-8">
          <h2 className="text-3xl font-bold mb-2">
            Welcome back, {user.fullName.split(' ')[0]}!
          </h2>
          <p className="text-blue-100">
            {isAdmin 
              ? 'Manage your subscription platform and oversee all users and billing.'
              : 'Track your subscriptions and manage your account settings.'
            }
          </p>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <ActionCard
            icon={<CreditCard className="w-6 h-6" />}
            title="Subscriptions"
            description={isAdmin ? "Manage all subscriptions" : "View your subscriptions"}
            color="blue"
          />
          
          {isAdmin && (
            <ActionCard
              icon={<Users className="w-6 h-6" />}
              title="User Management"
              description="Manage system users"
              color="purple"
            />
          )}
          
          <ActionCard
            icon={<Settings className="w-6 h-6" />}
            title="Settings"
            description="Account preferences"
            color="gray"
          />
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <StatsCard
            title="Active Subscriptions"
            value="12"
            change="+2 this month"
            positive={true}
          />
          <StatsCard
            title="Total Revenue"
            value="$2,450"
            change="+15% from last month"
            positive={true}
          />
          <StatsCard
            title={isAdmin ? "Total Users" : "Days Active"}
            value={isAdmin ? "156" : "45"}
            change={isAdmin ? "+8 this week" : "since registration"}
            positive={true}
          />
        </div>
      </main>
    </div>
  );
}

interface ActionCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  color: 'blue' | 'purple' | 'gray';
}

function ActionCard({ icon, title, description, color }: ActionCardProps) {
  const colorClasses = {
    blue: 'bg-blue-50 text-blue-600 hover:bg-blue-100',
    purple: 'bg-purple-50 text-purple-600 hover:bg-purple-100',
    gray: 'bg-gray-50 text-gray-600 hover:bg-gray-100'
  };

  return (
    <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 hover:shadow-md transition-shadow cursor-pointer">
      <div className={`inline-flex items-center justify-center w-12 h-12 rounded-xl ${colorClasses[color]} mb-4`}>
        {icon}
      </div>
      <h3 className="text-lg font-semibold text-gray-900 mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
}

interface StatsCardProps {
  title: string;
  value: string;
  change: string;
  positive: boolean;
}

function StatsCard({ title, value, change, positive }: StatsCardProps) {
  return (
    <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
      <h3 className="text-sm font-medium text-gray-600 mb-2">{title}</h3>
      <p className="text-3xl font-bold text-gray-900 mb-1">{value}</p>
      <p className={`text-sm ${positive ? 'text-green-600' : 'text-red-600'}`}>
        {change}
      </p>
    </div>
  );
}