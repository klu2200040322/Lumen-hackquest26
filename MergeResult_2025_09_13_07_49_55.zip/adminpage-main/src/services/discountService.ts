import { api } from './api';
import { Discount, ApiResponse } from '../types';

export const discountService = {
  getDiscounts: (): Promise<ApiResponse<Discount[]>> => {
    // Mock data for demonstration
    return Promise.resolve({
      data: [
        {
          id: '1',
          code: 'SUMMER2024',
          description: 'Summer special discount',
          type: 'percentage',
          value: 25,
          minAmount: 10,
          maxDiscount: 50,
          expiresAt: '2024-08-31',
          isActive: true,
          usageCount: 156,
          maxUsage: 1000,
        },
        {
          id: '2',
          code: 'WELCOME10',
          description: 'Welcome discount for new users',
          type: 'fixed',
          value: 10,
          expiresAt: '2024-12-31',
          isActive: true,
          usageCount: 89,
          maxUsage: 500,
        },
        {
          id: '3',
          code: 'BLACKFRIDAY',
          description: 'Black Friday mega sale',
          type: 'percentage',
          value: 50,
          minAmount: 50,
          expiresAt: '2024-11-30',
          isActive: false,
          usageCount: 2341,
          maxUsage: 5000,
        },
      ],
      success: true,
    });
  },

  createDiscount: (discount: Omit<Discount, 'id' | 'usageCount'>): Promise<ApiResponse<Discount>> =>
    api.post('/discounts', discount),

  updateDiscount: (id: string, discount: Partial<Discount>): Promise<ApiResponse<Discount>> =>
    api.put(`/discounts/${id}`, discount),

  deleteDiscount: (id: string): Promise<ApiResponse<void>> =>
    api.delete(`/discounts/${id}`),
};