import { api } from './api';
import { Plan, ApiResponse } from '../types';

export const planService = {
  getPlans: (): Promise<ApiResponse<Plan[]>> => {
    // Mock data for demonstration
    return Promise.resolve({
      data: [
        {
          id: '1',
          name: 'Basic',
          description: 'Perfect for individuals',
          price: 9.99,
          interval: 'monthly',
          features: ['10 Projects', '5GB Storage', 'Email Support'],
          isActive: true,
          createdAt: '2024-01-01',
          subscribers: 1250,
        },
        {
          id: '2',
          name: 'Pro',
          description: 'Great for small teams',
          price: 29.99,
          interval: 'monthly',
          features: ['Unlimited Projects', '50GB Storage', 'Priority Support', 'Advanced Analytics'],
          isActive: true,
          createdAt: '2024-01-01',
          subscribers: 842,
        },
        {
          id: '3',
          name: 'Enterprise',
          description: 'For large organizations',
          price: 99.99,
          interval: 'monthly',
          features: ['Everything in Pro', '500GB Storage', 'Phone Support', 'Custom Integrations', 'SLA'],
          isActive: true,
          createdAt: '2024-01-01',
          subscribers: 156,
        },
      ],
      success: true,
    });
  },

  getPlan: (id: string): Promise<ApiResponse<Plan>> =>
    api.get(`/plans/${id}`),

  createPlan: (plan: Omit<Plan, 'id' | 'createdAt' | 'subscribers'>): Promise<ApiResponse<Plan>> =>
    api.post('/plans', plan),

  updatePlan: (id: string, plan: Partial<Plan>): Promise<ApiResponse<Plan>> =>
    api.put(`/plans/${id}`, plan),

  deletePlan: (id: string): Promise<ApiResponse<void>> =>
    api.delete(`/plans/${id}`),
};