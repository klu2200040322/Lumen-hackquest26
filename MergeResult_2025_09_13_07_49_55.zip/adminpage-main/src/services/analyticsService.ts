import { api } from './api';
import { AnalyticsData, ApiResponse } from '../types';

export const analyticsService = {
  getAnalytics: (): Promise<ApiResponse<AnalyticsData>> => {
    // Mock data for demonstration
    return Promise.resolve({
      data: {
        totalRevenue: 45678.90,
        totalSubscribers: 2248,
        churnRate: 3.2,
        averageRevenuePerUser: 24.50,
        subscriptionTrends: [
          { date: '2024-01-01', subscriptions: 1850, revenue: 35420, newUsers: 145 },
          { date: '2024-01-02', subscriptions: 1872, revenue: 36180, newUsers: 156 },
          { date: '2024-01-03', subscriptions: 1901, revenue: 37250, newUsers: 167 },
          { date: '2024-01-04', subscriptions: 1935, revenue: 38120, newUsers: 178 },
          { date: '2024-01-05', subscriptions: 1968, revenue: 39340, newUsers: 189 },
          { date: '2024-01-06', subscriptions: 2012, revenue: 40890, newUsers: 201 },
          { date: '2024-01-07', subscriptions: 2048, revenue: 42150, newUsers: 192 },
          { date: '2024-01-08', subscriptions: 2089, revenue: 43680, newUsers: 203 },
          { date: '2024-01-09', subscriptions: 2134, revenue: 44920, newUsers: 215 },
          { date: '2024-01-10', subscriptions: 2178, revenue: 46340, newUsers: 187 },
          { date: '2024-01-11', subscriptions: 2203, revenue: 47120, newUsers: 168 },
          { date: '2024-01-12', subscriptions: 2248, revenue: 48780, newUsers: 179 },
        ],
        planDistribution: [
          { planName: 'Basic', subscribers: 1250, revenue: 12497.50 },
          { planName: 'Pro', subscribers: 842, revenue: 25258.58 },
          { planName: 'Enterprise', subscribers: 156, revenue: 15599.44 },
        ],
      },
      success: true,
    });
  },

  getAIInsights: (): Promise<ApiResponse<string[]>> => {
    // Mock AI insights
    return Promise.resolve({
      data: [
        'Pro plan shows 23% higher retention rate compared to Basic plan',
        'Weekend sign-ups have 15% lower churn rate than weekday sign-ups',
        'Users who activate within 24 hours have 40% better long-term retention',
        'Revenue growth is accelerating at 12% month-over-month',
        'Consider launching a mid-tier plan between Basic and Pro',
        'Summer discount campaign increased conversions by 31%',
      ],
      success: true,
    });
  },
};