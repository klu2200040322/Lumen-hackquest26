import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Layout } from './components/layout/Layout';
import { Dashboard } from './pages/Dashboard';
import { PlanManagement } from './pages/PlanManagement';
import { DiscountManagement } from './pages/DiscountManagement';
import { Notifications } from './pages/Notifications';
import { Analytics } from './pages/Analytics';

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/plans" element={<PlanManagement />} />
          <Route path="/discounts" element={<DiscountManagement />} />
          <Route path="/notifications" element={<Notifications />} />
          <Route path="/analytics" element={<Analytics />} />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;