import React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';

interface SubscriptionChartProps {
  data: Array<{
    date: string;
    subscriptions: number;
    revenue: number;
    newUsers: number;
  }>;
}

export const SubscriptionChart: React.FC<SubscriptionChartProps> = ({ data }) => {
  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric' 
    });
  };

  const formatCurrency = (value: number) => {
    return `$${(value / 1000).toFixed(1)}k`;
  };

  return (
    <ResponsiveContainer width="100%" height={400}>
      <LineChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
        <XAxis 
          dataKey="date" 
          tickFormatter={formatDate}
          className="text-xs"
        />
        <YAxis 
          yAxisId="left"
          tickFormatter={formatCurrency}
          className="text-xs"
        />
        <YAxis 
          yAxisId="right" 
          orientation="right"
          className="text-xs"
        />
        <Tooltip
          formatter={(value: number, name: string) => {
            if (name === 'Revenue') {
              return [`$${value.toLocaleString()}`, name];
            }
            return [value.toLocaleString(), name];
          }}
          labelFormatter={formatDate}
          contentStyle={{
            backgroundColor: 'white',
            border: '1px solid #e5e7eb',
            borderRadius: '8px',
            boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
          }}
        />
        <Legend />
        <Line
          yAxisId="left"
          type="monotone"
          dataKey="revenue"
          stroke="#3b82f6"
          strokeWidth={3}
          name="Revenue"
          dot={{ fill: '#3b82f6', strokeWidth: 2, r: 4 }}
          activeDot={{ r: 6, fill: '#3b82f6' }}
        />
        <Line
          yAxisId="right"
          type="monotone"
          dataKey="subscriptions"
          stroke="#10b981"
          strokeWidth={2}
          name="Total Subscriptions"
          dot={{ fill: '#10b981', strokeWidth: 2, r: 3 }}
        />
        <Line
          yAxisId="right"
          type="monotone"
          dataKey="newUsers"
          stroke="#f97316"
          strokeWidth={2}
          name="New Users"
          dot={{ fill: '#f97316', strokeWidth: 2, r: 3 }}
        />
      </LineChart>
    </ResponsiveContainer>
  );
};