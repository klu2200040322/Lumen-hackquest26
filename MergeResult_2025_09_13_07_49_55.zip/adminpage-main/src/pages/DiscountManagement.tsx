import React, { useState, useEffect } from 'react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Modal } from '../components/ui/Modal';
import { Table } from '../components/ui/Table';
import { discountService } from '../services/discountService';
import { Discount } from '../types';
import { Plus, Edit, Trash2, Percent, DollarSign } from 'lucide-react';

export const DiscountManagement: React.FC = () => {
  const [discounts, setDiscounts] = useState<Discount[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingDiscount, setEditingDiscount] = useState<Discount | null>(null);
  const [formData, setFormData] = useState({
    code: '',
    description: '',
    type: 'percentage' as 'percentage' | 'fixed',
    value: 0,
    minAmount: '',
    maxDiscount: '',
    maxUsage: '',
    expiresAt: '',
    isActive: true,
  });

  useEffect(() => {
    fetchDiscounts();
  }, []);

  const fetchDiscounts = async () => {
    try {
      const response = await discountService.getDiscounts();
      setDiscounts(response.data);
    } catch (error) {
      console.error('Failed to fetch discounts:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenModal = (discount?: Discount) => {
    if (discount) {
      setEditingDiscount(discount);
      setFormData({
        code: discount.code,
        description: discount.description,
        type: discount.type,
        value: discount.value,
        minAmount: discount.minAmount?.toString() || '',
        maxDiscount: discount.maxDiscount?.toString() || '',
        maxUsage: discount.maxUsage?.toString() || '',
        expiresAt: discount.expiresAt.split('T')[0],
        isActive: discount.isActive,
      });
    } else {
      setEditingDiscount(null);
      setFormData({
        code: '',
        description: '',
        type: 'percentage',
        value: 0,
        minAmount: '',
        maxDiscount: '',
        maxUsage: '',
        expiresAt: '',
        isActive: true,
      });
    }
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingDiscount(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const discountData = {
        ...formData,
        minAmount: formData.minAmount ? parseFloat(formData.minAmount) : undefined,
        maxDiscount: formData.maxDiscount ? parseFloat(formData.maxDiscount) : undefined,
        maxUsage: formData.maxUsage ? parseInt(formData.maxUsage) : undefined,
      };

      if (editingDiscount) {
        await discountService.updateDiscount(editingDiscount.id, discountData);
      } else {
        await discountService.createDiscount(discountData);
      }
      
      await fetchDiscounts();
      handleCloseModal();
    } catch (error) {
      console.error('Failed to save discount:', error);
    }
  };

  const handleDeleteDiscount = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this discount?')) {
      try {
        await discountService.deleteDiscount(id);
        await fetchDiscounts();
      } catch (error) {
        console.error('Failed to delete discount:', error);
      }
    }
  };

  const columns = [
    {
      key: 'code' as keyof Discount,
      header: 'Code',
      render: (value: string, discount: Discount) => (
        <div>
          <p className="font-medium text-gray-900 font-mono">{value}</p>
          <p className="text-sm text-gray-500">{discount.description}</p>
        </div>
      ),
    },
    {
      key: 'type' as keyof Discount,
      header: 'Type & Value',
      render: (value: string, discount: Discount) => (
        <div className="flex items-center">
          {discount.type === 'percentage' ? (
            <Percent className="w-4 h-4 mr-1 text-green-600" />
          ) : (
            <DollarSign className="w-4 h-4 mr-1 text-blue-600" />
          )}
          <span className="font-medium">
            {discount.type === 'percentage' ? `${discount.value}%` : `$${discount.value}`}
          </span>
        </div>
      ),
    },
    {
      key: 'usageCount' as keyof Discount,
      header: 'Usage',
      render: (value: number, discount: Discount) => (
        <div>
          <p className="font-medium">{value.toLocaleString()}</p>
          {discount.maxUsage && (
            <p className="text-sm text-gray-500">
              of {discount.maxUsage.toLocaleString()}
            </p>
          )}
        </div>
      ),
    },
    {
      key: 'expiresAt' as keyof Discount,
      header: 'Expires',
      render: (value: string) => (
        <span className="text-sm">
          {new Date(value).toLocaleDateString()}
        </span>
      ),
    },
    {
      key: 'isActive' as keyof Discount,
      header: 'Status',
      render: (value: boolean) => (
        <span
          className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${
            value
              ? 'bg-green-100 text-green-800'
              : 'bg-red-100 text-red-800'
          }`}
        >
          {value ? 'Active' : 'Inactive'}
        </span>
      ),
    },
    {
      key: 'id' as keyof Discount,
      header: 'Actions',
      render: (value: string, discount: Discount) => (
        <div className="flex space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleOpenModal(discount)}
          >
            <Edit className="w-4 h-4" />
          </Button>
          <Button
            variant="danger"
            size="sm"
            onClick={() => handleDeleteDiscount(discount.id)}
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      ),
    },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Discount Management</h1>
          <p className="mt-2 text-gray-600">
            Create and manage promotional discount codes
          </p>
        </div>
        <Button onClick={() => handleOpenModal()}>
          <Plus className="w-4 h-4 mr-2" />
          Add Discount
        </Button>
      </div>

      <Card padding="none">
        <Table data={discounts} columns={columns} />
      </Card>

      <Modal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        title={editingDiscount ? 'Edit Discount' : 'Create New Discount'}
        size="lg"
      >
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Discount Code
              </label>
              <input
                type="text"
                value={formData.code}
                onChange={(e) => setFormData(prev => ({ ...prev, code: e.target.value.toUpperCase() }))}
                placeholder="SUMMER2024"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 font-mono"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Type
              </label>
              <select
                value={formData.type}
                onChange={(e) => setFormData(prev => ({ ...prev, type: e.target.value as 'percentage' | 'fixed' }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="percentage">Percentage</option>
                <option value="fixed">Fixed Amount</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Description
            </label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              rows={2}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {formData.type === 'percentage' ? 'Percentage (%)' : 'Amount ($)'}
              </label>
              <input
                type="number"
                step={formData.type === 'percentage' ? '1' : '0.01'}
                value={formData.value}
                onChange={(e) => setFormData(prev => ({ ...prev, value: parseFloat(e.target.value) }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Expires At
              </label>
              <input
                type="date"
                value={formData.expiresAt}
                onChange={(e) => setFormData(prev => ({ ...prev, expiresAt: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Min Amount ($)
              </label>
              <input
                type="number"
                step="0.01"
                value={formData.minAmount}
                onChange={(e) => setFormData(prev => ({ ...prev, minAmount: e.target.value }))}
                placeholder="Optional"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Max Discount ($)
              </label>
              <input
                type="number"
                step="0.01"
                value={formData.maxDiscount}
                onChange={(e) => setFormData(prev => ({ ...prev, maxDiscount: e.target.value }))}
                placeholder="Optional"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Max Usage
              </label>
              <input
                type="number"
                value={formData.maxUsage}
                onChange={(e) => setFormData(prev => ({ ...prev, maxUsage: e.target.value }))}
                placeholder="Unlimited"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="flex items-center">
              <input
                type="checkbox"
                checked={formData.isActive}
                onChange={(e) => setFormData(prev => ({ ...prev, isActive: e.target.checked }))}
                className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              />
              <span className="ml-2 text-sm text-gray-700">Active</span>
            </label>
          </div>

          <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200">
            <Button type="button" variant="outline" onClick={handleCloseModal}>
              Cancel
            </Button>
            <Button type="submit">
              {editingDiscount ? 'Update Discount' : 'Create Discount'}
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};