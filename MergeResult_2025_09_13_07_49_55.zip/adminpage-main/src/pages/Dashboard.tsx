import React, { useEffect, useState } from 'react';
import { Card } from '../components/ui/Card';
import { SubscriptionChart } from '../components/charts/SubscriptionChart';
import { analyticsService } from '../services/analyticsService';
import { AnalyticsData } from '../types';
import { DollarSign, Users, TrendingDown, TrendingUp } from 'lucide-react';

export const Dashboard: React.FC = () => {
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        const response = await analyticsService.getAnalytics();
        setAnalytics(response.data);
      } catch (error) {
        console.error('Failed to fetch analytics:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchAnalytics();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!analytics) return null;

  const stats = [
    {
      name: 'Total Revenue',
      value: `$${analytics.totalRevenue.toLocaleString()}`,
      change: '+12.5%',
      changeType: 'increase',
      icon: DollarSign,
    },
    {
      name: 'Total Subscribers',
      value: analytics.totalSubscribers.toLocaleString(),
      change: '+8.2%',
      changeType: 'increase',
      icon: Users,
    },
    {
      name: 'Churn Rate',
      value: `${analytics.churnRate}%`,
      change: '-0.8%',
      changeType: 'decrease',
      icon: TrendingDown,
    },
    {
      name: 'Avg Revenue per User',
      value: `$${analytics.averageRevenuePerUser}`,
      change: '+4.1%',
      changeType: 'increase',
      icon: TrendingUp,
    },
  ];

  return (
    <div className="space-y-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="mt-2 text-gray-600">
          Welcome back! Here's what's happening with your subscriptions today.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <Card key={stat.name} className="relative">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                  <stat.icon className="w-4 h-4 text-blue-600" />
                </div>
              </div>
              <div className="ml-4 flex-1">
                <p className="text-sm font-medium text-gray-600">{stat.name}</p>
                <div className="flex items-baseline">
                  <p className="text-2xl font-semibold text-gray-900">{stat.value}</p>
                  <span
                    className={`ml-2 text-sm font-medium ${
                      stat.changeType === 'increase'
                        ? 'text-green-600'
                        : 'text-red-600'
                    }`}
                  >
                    {stat.change}
                  </span>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="col-span-1 lg:col-span-2">
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-gray-900">
              Subscription Trends
            </h3>
            <p className="text-sm text-gray-600">
              Revenue and subscription growth over time
            </p>
          </div>
          <SubscriptionChart data={analytics.subscriptionTrends} />
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Recent Activity
          </h3>
          <div className="space-y-4">
            {[
              { action: 'New subscriber to Pro plan', time: '2 minutes ago', type: 'success' },
              { action: 'Payment failed for user@example.com', time: '1 hour ago', type: 'error' },
              { action: 'SUMMER2024 discount code used', time: '3 hours ago', type: 'info' },
              { action: 'Enterprise plan upgraded', time: '5 hours ago', type: 'success' },
            ].map((activity, index) => (
              <div key={index} className="flex items-center space-x-4 py-2">
                <div
                  className={`w-2 h-2 rounded-full ${
                    activity.type === 'success'
                      ? 'bg-green-500'
                      : activity.type === 'error'
                      ? 'bg-red-500'
                      : 'bg-blue-500'
                  }`}
                />
                <div className="flex-1">
                  <p className="text-sm text-gray-900">{activity.action}</p>
                  <p className="text-xs text-gray-500">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Quick Actions
          </h3>
          <div className="space-y-3">
            <button className="w-full text-left p-3 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors">
              <p className="font-medium text-blue-900">Create New Plan</p>
              <p className="text-sm text-blue-600">Add a new subscription plan</p>
            </button>
            <button className="w-full text-left p-3 bg-green-50 hover:bg-green-100 rounded-lg transition-colors">
              <p className="font-medium text-green-900">New Discount Code</p>
              <p className="text-sm text-green-600">Create promotional offer</p>
            </button>
            <button className="w-full text-left p-3 bg-purple-50 hover:bg-purple-100 rounded-lg transition-colors">
              <p className="font-medium text-purple-900">Export Data</p>
              <p className="text-sm text-purple-600">Download reports</p>
            </button>
          </div>
        </Card>
      </div>
    </div>
  );
};