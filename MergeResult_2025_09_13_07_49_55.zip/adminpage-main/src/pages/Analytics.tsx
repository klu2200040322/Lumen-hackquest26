import React, { useState, useEffect } from 'react';
import { Card } from '../components/ui/Card';
import { AnalyticsChart } from '../components/charts/AnalyticsChart';
import { analyticsService } from '../services/analyticsService';
import { AnalyticsData } from '../types';
import { Brain, TrendingUp, Users, DollarSign, Zap } from 'lucide-react';

export const Analytics: React.FC = () => {
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [insights, setInsights] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [analyticsResponse, insightsResponse] = await Promise.all([
          analyticsService.getAnalytics(),
          analyticsService.getAIInsights(),
        ]);
        
        setAnalytics(analyticsResponse.data);
        setInsights(insightsResponse.data);
      } catch (error) {
        console.error('Failed to fetch analytics data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!analytics) return null;

  const topPerformingPlan = analytics.planDistribution.reduce((max, plan) => 
    plan.revenue > max.revenue ? plan : max
  );

  const revenueGrowth = analytics.subscriptionTrends.length >= 2
    ? ((analytics.subscriptionTrends[analytics.subscriptionTrends.length - 1].revenue - 
        analytics.subscriptionTrends[0].revenue) / analytics.subscriptionTrends[0].revenue * 100)
    : 0;

  return (
    <div className="space-y-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Analytics & Insights</h1>
        <p className="mt-2 text-gray-600">
          AI-powered insights and detailed analytics for your subscription business
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <div className="flex items-center">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-blue-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total Revenue</p>
              <p className="text-2xl font-bold text-gray-900">
                ${analytics.totalRevenue.toLocaleString()}
              </p>
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <Users className="w-5 h-5 text-green-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Subscribers</p>
              <p className="text-2xl font-bold text-gray-900">
                {analytics.totalSubscribers.toLocaleString()}
              </p>
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center">
            <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-yellow-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Revenue Growth</p>
              <p className="text-2xl font-bold text-gray-900">
                {revenueGrowth > 0 ? '+' : ''}{revenueGrowth.toFixed(1)}%
              </p>
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center">
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-purple-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">ARPU</p>
              <p className="text-2xl font-bold text-gray-900">
                ${analytics.averageRevenuePerUser}
              </p>
            </div>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-gray-900">
              Plan Distribution
            </h3>
            <p className="text-sm text-gray-600">
              Revenue and subscriber breakdown by plan
            </p>
          </div>
          <AnalyticsChart data={analytics.planDistribution} />
        </Card>

        <Card>
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-gray-900">
              Plan Performance
            </h3>
            <p className="text-sm text-gray-600">
              Detailed metrics for each subscription plan
            </p>
          </div>
          
          <div className="space-y-4">
            {analytics.planDistribution.map((plan, index) => (
              <div key={plan.planName} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className={`w-4 h-4 rounded-full`} style={{ backgroundColor: ['#3b82f6', '#10b981', '#f97316'][index] }} />
                  <div>
                    <p className="font-medium text-gray-900">{plan.planName}</p>
                    <p className="text-sm text-gray-600">{plan.subscribers} subscribers</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium text-gray-900">${plan.revenue.toLocaleString()}</p>
                  <p className="text-sm text-gray-600">
                    ${(plan.revenue / plan.subscribers).toFixed(2)} ARPU
                  </p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card>
        <div className="flex items-center mb-6">
          <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-blue-600 rounded-lg flex items-center justify-center mr-3">
            <Brain className="w-4 h-4 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900">AI-Powered Insights</h3>
            <p className="text-sm text-gray-600">
              Intelligent recommendations based on your data patterns
            </p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {insights.map((insight, index) => (
            <div 
              key={index}
              className="p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border border-blue-100"
            >
              <div className="flex items-start space-x-3">
                <div className="w-6 h-6 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-white text-xs font-bold">{index + 1}</span>
                </div>
                <p className="text-sm text-gray-700 leading-relaxed">{insight}</p>
              </div>
            </div>
          ))}
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Top Performing Plan
          </h3>
          <div className="text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
              <TrendingUp className="w-8 h-8 text-green-600" />
            </div>
            <p className="text-2xl font-bold text-gray-900 mb-1">
              {topPerformingPlan.planName}
            </p>
            <p className="text-sm text-gray-600 mb-3">
              ${topPerformingPlan.revenue.toLocaleString()} revenue
            </p>
            <div className="bg-green-50 rounded-lg p-3">
              <p className="text-sm text-green-800">
                {topPerformingPlan.subscribers} active subscribers
              </p>
            </div>
          </div>
        </Card>

        <Card>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Churn Analysis
          </h3>
          <div className="text-center">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-3">
              <Users className="w-8 h-8 text-red-600" />
            </div>
            <p className="text-3xl font-bold text-gray-900 mb-1">
              {analytics.churnRate}%
            </p>
            <p className="text-sm text-gray-600 mb-3">Current churn rate</p>
            <div className="bg-green-50 rounded-lg p-3">
              <p className="text-sm text-green-800">
                ↓ 0.8% vs last month
              </p>
            </div>
          </div>
        </Card>

        <Card>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Growth Forecast
          </h3>
          <div className="text-center">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
              <Brain className="w-8 h-8 text-blue-600" />
            </div>
            <p className="text-2xl font-bold text-gray-900 mb-1">
              2,890
            </p>
            <p className="text-sm text-gray-600 mb-3">
              Projected subscribers next month
            </p>
            <div className="bg-blue-50 rounded-lg p-3">
              <p className="text-sm text-blue-800">
                +28% growth potential
              </p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};