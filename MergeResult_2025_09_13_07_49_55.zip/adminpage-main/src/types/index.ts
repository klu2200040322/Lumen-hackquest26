export interface Plan {
  id: string;
  name: string;
  description: string;
  price: number;
  interval: 'monthly' | 'yearly';
  features: string[];
  isActive: boolean;
  createdAt: string;
  subscribers: number;
}

export interface Discount {
  id: string;
  code: string;
  description: string;
  type: 'percentage' | 'fixed';
  value: number;
  minAmount?: number;
  maxDiscount?: number;
  expiresAt: string;
  isActive: boolean;
  usageCount: number;
  maxUsage?: number;
}

export interface Subscription {
  id: string;
  planId: string;
  userId: string;
  status: 'active' | 'cancelled' | 'expired' | 'pending';
  startDate: string;
  endDate: string;
  amount: number;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'warning' | 'error' | 'success';
  isRead: boolean;
  createdAt: string;
}

export interface AnalyticsData {
  totalRevenue: number;
  totalSubscribers: number;
  churnRate: number;
  averageRevenuePerUser: number;
  subscriptionTrends: Array<{
    date: string;
    subscriptions: number;
    revenue: number;
    newUsers: number;
  }>;
  planDistribution: Array<{
    planName: string;
    subscribers: number;
    revenue: number;
  }>;
}

export interface ApiResponse<T> {
  data: T;
  success: boolean;
  message?: string;
}